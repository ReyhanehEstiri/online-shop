// BookDetails.js
import React, { useState, useEffect } from 'react';
import Books from './book.js';

const BookDetails = () => {
  const [bookData, setBookData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchBookDetails = async () => {
      try {
        const response = await fetch('http://localhost:7266/api/v1/Book/GetBookDetails', {
          method: 'GET',
          headers: {
            'accept': '*/*',
          },
        });

        if (!response.ok) {
          throw new Error('Failed to fetch book details');
        }

        const data = await response.json();
        setBookData(data);
      } catch (error) {
        console.error('Error fetching book details:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchBookDetails();
  }, []);

  const addToCart = async () => {
    try {
      const response = await fetch('http://localhost:7266/api/v1/Book/AddToCart', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          bookId: bookData.id,
          quantity: 1,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to add to cart');
      }

      alert('Added to Cart!');
    } catch (error) {
      console.error('Error adding to cart:', error);
    }
  };

  const addToWishlist = async () => {
    try {
      const response = await fetch('http://localhost:7266/api/v1/Book/AddToWishList', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          bookId: bookData.id,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to add to wishlist');
      }

      alert('Added to Wishlist!');
    } catch (error) {
      console.error('Error adding to wishlist:', error);
    }
  };

  return (
    <div>
      <h1>Book Details</h1>
      {isLoading ? (
        <p>Loading...</p>
      ) : (
        <Books {...bookData} onAddToCart={addToCart} onAddToWishlist={addToWishlist} />
      )}
    </div>
  );
};

export default BookDetails;
